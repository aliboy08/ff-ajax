<?php
/**
 * Plugin Name: FF Ajax
 * Plugin URI: https://www.fivebyfive.com.au/
 * Description: Simplify development involving ajax
 * Version: 1.1.2
 * Author: Five by Five
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) die();

include_once 'functions.php';
include_once 'class-ff-ajax.php';