<div class="item-sample">
<?php pre_debug($post->post_title); ?>
</div>